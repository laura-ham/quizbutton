var searchData=
[
  ['badpincheck',['badPinCheck',['../group__digital_pin.html#ga107992311bca47c7ebee5afdedc280e0',1,'DigitalPin.h']]],
  ['badpinnumber',['badPinNumber',['../group__digital_pin.html#ga2a50c39692fdc6a7be0f614f6d730bfe',1,'DigitalPin.h']]],
  ['begin',['begin',['../group__runtime_digital.html#gadb77365e03a408350ccb22b827511268',1,'PinIO::begin()'],['../group__soft_i2_c.html#gaae933eff7266316dd7bfcf00ec35dc2a',1,'SoftI2cMaster::begin()'],['../class_fast_i2c_master.html#a59dfd0c039296f10b85b3de6ea98798d',1,'FastI2cMaster::begin()'],['../class_soft_s_p_i.html#a8086e47eeb663d943e2281c814af67eb',1,'SoftSPI::begin()']]]
];
