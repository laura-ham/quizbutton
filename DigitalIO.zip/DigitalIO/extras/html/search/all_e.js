var searchData=
[
  ['sck_5fmode',['SCK_MODE',['../group__soft_s_p_i.html#gac9d2cd28bbc5b023abb24fc1ab56d34e',1,'SoftSPI.h']]],
  ['send',['send',['../class_soft_s_p_i.html#aec803c1e30f66ccfdf2ca885964e49f1',1,'SoftSPI']]],
  ['software_20i2c',['Software I2C',['../group__soft_i2_c.html',1,'']]],
  ['softi2cmaster',['SoftI2cMaster',['../class_soft_i2c_master.html',1,'SoftI2cMaster'],['../group__soft_i2_c.html#ga7204e8a90254de24c0a0548b36ffe9a3',1,'SoftI2cMaster::SoftI2cMaster()']]],
  ['softi2cmaster_2ecpp',['SoftI2cMaster.cpp',['../_soft_i2c_master_8cpp.html',1,'']]],
  ['softi2cmaster_2eh',['SoftI2cMaster.h',['../_soft_i2c_master_8h.html',1,'']]],
  ['softspi',['SoftSPI',['../class_soft_s_p_i.html',1,'SoftSPI&lt; MisoPin, MosiPin, SckPin, Mode &gt;'],['../group__soft_s_p_i.html',1,'(Global Namespace)']]],
  ['softspi_2eh',['SoftSPI.h',['../_soft_s_p_i_8h.html',1,'']]],
  ['start',['start',['../class_i2c_master_base.html#ac2e8be9d2809d31b0e456860ef357345',1,'I2cMasterBase::start()'],['../group__soft_i2_c.html#ga8ee650a6348bd7472c6ac6fb5c5265f5',1,'SoftI2cMaster::start()'],['../class_fast_i2c_master.html#ad64911a142973667a094b3ce051a5412',1,'FastI2cMaster::start()']]],
  ['state_5frep_5fstart',['STATE_REP_START',['../group__soft_i2_c.html#ga950c0757df97cfc0a1f7fddaf21fd2a0',1,'SoftI2cMaster.h']]],
  ['state_5frx_5faddr_5fnack',['STATE_RX_ADDR_NACK',['../group__soft_i2_c.html#gaa42d42b48050ecdfb2111b669d892bb1',1,'SoftI2cMaster.h']]],
  ['state_5frx_5fdata',['STATE_RX_DATA',['../group__soft_i2_c.html#gad2cd52a768c24fa4e2ecf788835db429',1,'SoftI2cMaster.h']]],
  ['state_5fstop',['STATE_STOP',['../group__soft_i2_c.html#ga6303d577c073ad6b8c3350d96223c426',1,'SoftI2cMaster.h']]],
  ['state_5ftx_5faddr_5fnack',['STATE_TX_ADDR_NACK',['../group__soft_i2_c.html#gab17e0ed11b1eacfc8ceb714d9497f1db',1,'SoftI2cMaster.h']]],
  ['state_5ftx_5fdata',['STATE_TX_DATA',['../group__soft_i2_c.html#ga7f1b7aae9c4b0db47d08e603ed3dbd22',1,'SoftI2cMaster.h']]],
  ['state_5ftx_5fdata_5fnack',['STATE_TX_DATA_NACK',['../group__soft_i2_c.html#ga58292e5be793935a299a1f9738039f92',1,'SoftI2cMaster.h']]],
  ['stop',['stop',['../class_i2c_master_base.html#a8cbf416c6bbf9135bd5f0331ff1951d2',1,'I2cMasterBase::stop()'],['../group__soft_i2_c.html#gad8f52e1cbf15894472881afe439afa02',1,'SoftI2cMaster::stop()'],['../class_fast_i2c_master.html#a176dbc10bf47c581a5dfe042bfc430a3',1,'FastI2cMaster::stop()']]]
];
