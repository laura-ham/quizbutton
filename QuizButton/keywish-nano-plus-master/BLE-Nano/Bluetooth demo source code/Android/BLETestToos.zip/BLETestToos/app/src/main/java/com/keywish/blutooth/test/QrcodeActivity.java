package com.keywish.blutooth.test;


import android.app.Activity;
import android.os.Bundle;

import com.keywish.blutooth.test.R;

public class QrcodeActivity extends Activity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        // TODO Auto-generated method stub
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_qrcode);
    }
}